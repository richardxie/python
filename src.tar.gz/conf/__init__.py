#!/usr/bin/python2.7
# ！-*- coding: utf-8 -*-
db_config = {
    "mysql" : {
        'host':'10.10.32.51',
        'port':'3306',
        'user':'uY2XtL5HSIqaBg8T',
        'instancename':'vSFJz7EQNIyBdOXA',
        'password':'pGEI8bdCqFer9mTMS'
    },
    "mysql-dev" : {
        'host':'192.16.2.139',
        'port':'3306',
        'user':'admin',
        'instancename':'test',
        'password':'admin'
    },
    "sqlite3" : {
        'host':'',
        'dbname':'/usr/src/vagrant/test.db'
    },
    "sqlite3-dev" : {
        'host':'',
        'dbname':'test.db'
    }
}

auto_tender_names = ['richardxieq','emmaye']
