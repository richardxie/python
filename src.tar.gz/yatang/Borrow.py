#!/usr/bin/python2.7
# ！-*- coding: utf-8 -*-

class Borrow(object): 
    def __init__(self, ibid, bt, bn):
        self.ibid = ibid
        self.borrowType = bt
        self.borrowNum = bn
